package com.selinium.base;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selinium.pom.Email_submit;
import com.selinium.pom.Registration;
import com.selinium.util.Xls_Reader;

public class Testbase {
public static WebDriver driver=null;
public static WebDriverWait wait=null;
public static Xls_Reader suiteAxls=null;
public static boolean isInitalized=false;

public static FileInputStream fileInput = null;
public static FileOutputStream fileOutput = null;

public static Properties prop = null;

public static WebElement element=null;
public static String browser;


public void initialize()
{
	// DOMConfigurator.configure("log4j.xml");
	if(!isInitalized){
suiteAxls = new Xls_Reader(System.getProperty("user.dir")+"\\src\\com\\selinium\\testdata\\TestData.xlsx");
isInitalized=true;
}
}
}
