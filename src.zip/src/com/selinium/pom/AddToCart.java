package com.selinium.pom;




import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selinium.base.Testbase;

public class AddToCart extends Testbase {
	
	public static List<WebElement> list=null;
	
	public static WebElement cartEmail(WebDriver driver) {
		element = driver.findElement(By.id("email"));
		return element;

	}
	
	public static WebElement cartpswd(WebDriver driver) {
		element = driver.findElement(By.id("passwd"));
		return element;

	}
	
	public static WebElement cartLogin(WebDriver driver) {
		element = driver.findElement(By.id("SubmitLogin"));
		return element;

	}

	public static WebElement selectItem(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.tagName("a")));
		list=driver.findElements(By.tagName("a"));
		return list.get(8);

	}
	
	public static WebElement addCart(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Add to cart")));
		return element;

	}
	
	
	public static WebElement verify(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.className("icon-ok")));
		return element;
}
}
