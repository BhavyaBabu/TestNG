package com.selinium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selinium.base.Testbase;

public class Registration extends Testbase {

	/*public static WebElement male(WebDriver driver, WebDriverWait wait) {
		element = (WebElement) wait.until(ExpectedConditions.elementToBeClickable(By.id("id_gender1")));
		return element;
	}

	public static WebElement female(WebDriver driver, WebDriverWait wait) {
		element = (WebElement) wait.until(ExpectedConditions.elementToBeClickable(By.id("id_gender2")));
		return element;
	}

	public static WebElement firstname(WebDriver driver) {
		element = driver.findElement(By.id("customer_firstname"));
		return element;
	}

	public static WebElement lastname(WebDriver driver) {
		element = driver.findElement(By.id("customer_lastname"));
		return element;
	}
	public static WebElement password(WebDriver driver) {
		element = driver.findElement(By.id("passwd"));
		return element;
	}

	public static WebElement day(WebDriver driver) {
		element = driver.findElement(By.id("days"));
		return element;
	}

	public static WebElement month(WebDriver driver) {
		element = driver.findElement(By.id("months"));
		return element;
	}

	public static WebElement year(WebDriver driver) {
		element = driver.findElement(By.id("years"));
		return element;
	}

	

	public static WebElement company(WebDriver driver) {
		element = driver.findElement(By.id("company"));
		return element;
	}

	public static WebElement addr1(WebDriver driver) {
		element = driver.findElement(By.id("address1"));
		return element;
	}

	public static WebElement addr2(WebDriver driver) {
		element = driver.findElement(By.id("address2"));
		return element;
	}

	public static WebElement city(WebDriver driver) {
		element = driver.findElement(By.id("city"));
		return element;
	}

	public static WebElement state(WebDriver driver) {
		element =driver.findElement(By.id("id_state"));
		return element;
	}

	public static WebElement postcode(WebDriver driver) {
		element = driver.findElement(By.id("postcode"));
		return element;
	}

	public static WebElement country(WebDriver driver) {
		element =driver.findElement(By.id("id_country"));
		return element;
	}

	public static WebElement other(WebDriver driver) {
		element = driver.findElement(By.id("other"));
		return element;
	}

	public static WebElement phone(WebDriver driver) {
		element = driver.findElement(By.id("phone"));
		return element;
	}

	public static WebElement mobile(WebDriver driver) {
		element = driver.findElement(By.id("phone_mobile"));
		return element;
	}

	public static WebElement alias(WebDriver driver) {
		element = driver.findElement(By.id("alias"));
		return element;
	}

	public static WebElement acc_submit(WebDriver driver) {
		element = driver.findElement(By.id("submitAccount"));
		return element;
	}
	
	public static WebElement next_page(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.id("my-account")));
		return element;
	}
	*/
	
	
	@FindBy(how = How.ID, using ="id_gender1")
	public static WebElement gender1;
	
	@FindBy(how = How.ID, using ="id_gender2")
	public static WebElement gender2;
	
	@FindBy(how = How.ID, using ="customer_firstname")
	public static WebElement firstname;
	
	@FindBy(how = How.ID, using ="customer_lastname")
	public static WebElement lastname;
	
	@FindBy(how = How.ID, using ="passwd")
	public static WebElement password;
	
	@FindBy(how = How.ID, using ="days")
	public static WebElement days;
	
	@FindBy(how = How.ID, using ="months")
	public static WebElement months;
	
	@FindBy(how = How.ID, using ="years")
	public static WebElement years;
	
	@FindBy(how = How.ID, using ="company")
	public static WebElement company;
	
	@FindBy(how = How.ID, using ="address1")
	public static WebElement address1;
	
	@FindBy(how = How.ID, using ="address2")
	public static WebElement address2;
	
	@FindBy(how = How.ID, using ="city")
	public static WebElement city;
	
	@FindBy(how = How.ID, using ="id_state")
	public static WebElement state;
	
	@FindBy(how = How.ID, using ="postcode")
	public static WebElement postcode;
	
	@FindBy(how = How.ID, using ="id_country")
	public static WebElement country;
	
	@FindBy(how = How.ID, using ="other")
	public static WebElement other;
	
	@FindBy(how = How.ID, using ="phone")
	public static WebElement phone;
	
	@FindBy(how = How.ID, using ="phone_mobile")
	public static WebElement phone_mobile;
	
	@FindBy(how = How.ID, using ="alias")
	public static WebElement alias;
	
	@FindBy(how = How.ID, using ="submitAccount")
	public static WebElement submit;
	
	
	public Registration(WebDriver driver) { 
		 
	    this.driver = driver; 
	 
	    } 
}
