package com.selinium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selinium.base.Testbase;


public class AcceptPage extends Testbase {

	
	public static WebElement acceptpage(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.name("button")));
		return element;
	}

}
