package com.selinium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selinium.base.Testbase;

public class HomePage extends Testbase {

	public static WebElement Signin_Link(WebDriver driver) {
		element = driver.findElement(By.linkText("Sign in"));
		return element;
	}

	public static WebElement home(WebDriver driver) {
		element = driver.findElement(By.id("search_query_top"));
		return element;

	}

	public static WebElement submit(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.name("submit_search")));
		return element;

	}

	public static WebElement FindElement(WebDriver driver, WebDriverWait wait) {
		element = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Printed Chiffon Dress")));
		return element;

	}

}
