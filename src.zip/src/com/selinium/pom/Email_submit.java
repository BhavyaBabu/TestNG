package com.selinium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selinium.base.Testbase;

public class Email_submit extends Testbase{

	
	/*public static WebElement email(WebDriver driver)
    {
        element = driver.findElement(By.id("email_create"));
        return element;
    }
	
	
	
	public static WebElement submit_create(WebDriver driver, WebDriverWait wait){
		element = wait.until(ExpectedConditions.elementToBeClickable(By.id("SubmitCreate")));
		return element;
	}*/
	
	@FindBy(id="email_create")
	public static WebElement emailCreate;
	
	@FindBy(id="SubmitCreate")
	public static WebElement SubmitCreate;
	
	public Email_submit(WebDriver driver) { 
		 
	    this.driver = driver; 
	 
	    } 
	
}
