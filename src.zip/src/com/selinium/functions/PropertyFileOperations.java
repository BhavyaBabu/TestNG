package com.selinium.functions;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import com.selinium.base.Testbase;

public class PropertyFileOperations extends Testbase{
	
	public static void userSetFile(String username,String password) throws IOException{
		
		prop = new Properties();
		fileOutput = new FileOutputStream(System.getProperty("user.dir") + 
				                                          "\\src\\com\\selinium\\config\\logindetails.properties");
		prop.setProperty("username", username);
		prop.setProperty("password", password);
		prop.store(fileOutput, null);
	}
	
	public static Object[][] userGetFile() throws IOException{
		
		prop = new Properties();
		Object[][] logindetails=null;
		fileInput = new FileInputStream(System.getProperty("user.dir") + 
				                                          "\\src\\com\\selinium\\config\\logindetails.properties");
		
		prop.load(fileInput);
		logindetails=new Object[1][2]; 
		logindetails[0][0]=prop.getProperty("username");
		logindetails[0][1]=prop.getProperty("password");
		
		return logindetails;
		
	}
	
	


}
