package com.selinium.functions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selinium.base.Testbase;

public class UserBrowser extends Testbase {

	public static void openbrowser(String browser,String url) {

		/*try {
			fileInput = new FileInputStream(System.getProperty("user.dir") + System.getProperty("file.separator")
					+ "src\\com\\selinium\\config\\config.properties");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		prop = new Properties();
		try {
			prop.load(fileInput);
		} catch (IOException e) {

			e.printStackTrace();
		}
*/
		// opening the browser
		
		if(browser.equals("chrome"))
		{
		System.setProperty("webdriver.chrome.driver", "D:\\jar\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.get(url);
		//wait=new WebDriverWait(driver,200);
		}
		else if(browser.equals("internetExplorer"))
		{
			/*DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			
			capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			capabilities.setCapability("allow-blocked-content", true);
			capabilities.setCapability("allowBlockedContent", true);*/
			
		System.setProperty("webdriver.ie.driver", "D:\\jar\\IEDriver.exe");
		driver = new InternetExplorerDriver();
		
		
		//driver.get(prop.getProperty("url"));
		}
		driver.get(url);
		wait=new WebDriverWait(driver,200);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//}
		/*System.setProperty("webdriver.chrome.driver", "D:\\jar\\IEDriveServer.exe");*/
	}
	


	public static void closeBrowser() {
		// closing the browser
		driver.quit();

	}
}
