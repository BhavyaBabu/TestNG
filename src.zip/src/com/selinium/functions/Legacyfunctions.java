package com.selinium.functions;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.selinium.base.Testbase;
import com.selinium.pom.AcceptPage;
import com.selinium.pom.AddToCart;
import com.selinium.pom.Email_submit;
import com.selinium.pom.HomePage;
import com.selinium.pom.Registration;

public class Legacyfunctions extends Testbase {

	public static boolean Searchitem(String searchitemname) {

		/*
		 * if (browser.equals("chrome")) { AcceptPage.acceptpage(driver,
		 * wait).click(); }
		 */

		String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL, Keys.RETURN);

		driver.findElement(By.name("button")).sendKeys(selectLinkOpeninNewTab);

		ArrayList<String> handle = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(handle.get(1));
		// Log.info("String started");
		// Log.error("error Message");

		HomePage.home(driver).sendKeys(searchitemname);
		Assert.assertEquals(HomePage.home(driver).getAttribute("value"), searchitemname);
		HomePage.submit(driver, wait).click();

		// WebElement element=HomePage.FindElement(driver, wait);

		if (element == null) {
			return false;
		} else {
			System.out.println("search pass");
			return true;
		}

	}

	public static boolean RegUser(String email, String gender, String firstname, String lastname, String password,
			String dob, String company, String address1, String address2, String city, String state, String pincode,
			String country, String add_info, String phone, String mobile, String alias) throws IOException {

		PageFactory.initElements(driver, Registration.class);
		PageFactory.initElements(driver, Email_submit.class);

		Select select = null;
		if (browser.equals("chrome")) {
			AcceptPage.acceptpage(driver, wait).click();
		}
		HomePage.Signin_Link(driver).click();

		/*
		 * email = email + System.currentTimeMillis() + "@gmail.com";
		 * Email_submit.email(driver).sendKeys(email);
		 * Assert.assertEquals(Email_submit.email(driver).getAttribute("value"),
		 * email);
		 * 
		 * Email_submit.submit_create(driver, wait).click();
		 */
		/*
		 * if (gender.equals("male")) { Registration.male(driver, wait).click();
		 * Assert.assertEquals(Registration.male(driver,
		 * wait).getAttribute("value"), "1"); } else {
		 * Registration.female(driver, wait).click();
		 * Assert.assertEquals(Registration.female(driver,
		 * wait).getAttribute("value"), "2"); }
		 * 
		 * Registration.firstname(driver).sendKeys(firstname);
		 * Assert.assertEquals(Registration.firstname(driver).getAttribute(
		 * "value"), firstname);
		 * 
		 * Registration.lastname(driver).sendKeys(lastname);
		 * Assert.assertEquals(Registration.lastname(driver).getAttribute(
		 * "value"), lastname);
		 * 
		 * Registration.password(driver).sendKeys(password);
		 * Assert.assertEquals(Registration.password(driver).getAttribute(
		 * "value"), password);
		 * 
		 * String date[] = dob.split("/"); select = new
		 * Select(Registration.day(driver)); select.selectByValue(date[0]);
		 * Assert.assertEquals(select.getFirstSelectedOption().getAttribute(
		 * "value"), date[0]);
		 * 
		 * select = new Select(Registration.month(driver));
		 * select.selectByValue(date[1]);
		 * Assert.assertEquals(select.getFirstSelectedOption().getAttribute(
		 * "value"), date[1]);
		 * 
		 * select = new Select(Registration.year(driver));
		 * select.selectByValue(date[2]);
		 * 
		 * Assert.assertEquals(select.getFirstSelectedOption().getAttribute(
		 * "value"), date[2]);
		 * 
		 * Registration.company(driver).sendKeys(company);
		 * Assert.assertEquals(Registration.company(driver).getAttribute("value"
		 * ), company);
		 * 
		 * Registration.addr1(driver).sendKeys(address1);
		 * Assert.assertEquals(Registration.addr1(driver).getAttribute("value"),
		 * address1);
		 * 
		 * Registration.addr2(driver).sendKeys(address2);
		 * Assert.assertEquals(Registration.addr2(driver).getAttribute("value"),
		 * address2);
		 * 
		 * Registration.city(driver).sendKeys(city);
		 * Assert.assertEquals(Registration.city(driver).getAttribute("value"),
		 * city);
		 * 
		 * select = new Select(Registration.state(driver));
		 * select.selectByVisibleText(state);
		 * Assert.assertEquals(select.getFirstSelectedOption().getText(),
		 * state);
		 * 
		 * Registration.postcode(driver).sendKeys(pincode);
		 * Assert.assertEquals(Registration.postcode(driver).getAttribute(
		 * "value"), pincode);
		 * 
		 * select = new Select(Registration.country(driver));
		 * select.selectByVisibleText(country);
		 * Assert.assertEquals(select.getFirstSelectedOption().getText(),
		 * country);
		 * 
		 * Registration.other(driver).sendKeys(add_info);
		 * Assert.assertEquals(Registration.other(driver).getAttribute("value"),
		 * add_info);
		 * 
		 * Registration.phone(driver).sendKeys(phone);
		 * Assert.assertEquals(Registration.phone(driver).getAttribute("value"),
		 * phone);
		 * 
		 * Registration.mobile(driver).sendKeys(mobile);
		 * Assert.assertEquals(Registration.mobile(driver).getAttribute("value")
		 * , mobile);
		 * 
		 * Registration.alias(driver).clear();
		 * Registration.alias(driver).sendKeys(alias);
		 * Assert.assertEquals(Registration.alias(driver).getAttribute("value"),
		 * alias);
		 * 
		 * Registration.acc_submit(driver).click();
		 */

		// WebElement element = Registration.next_page(driver, wait);

		email = email + System.currentTimeMillis() + "@gmail.com";
		Email_submit.emailCreate.sendKeys(email);
		Assert.assertEquals(Email_submit.emailCreate.getAttribute("value"), email);

		Email_submit.SubmitCreate.click();

		if (gender.equals("male")) {
			Registration.gender1.click();
			Assert.assertEquals(Registration.gender1.getAttribute("value"), "1");
		} else {
			Registration.gender2.click();
			Assert.assertEquals(Registration.gender2.getAttribute("value"), "2");
		}

		Registration.firstname.sendKeys(firstname);
		Assert.assertEquals(Registration.firstname.getAttribute("value"), firstname);
		Registration.lastname.sendKeys(lastname);
		Assert.assertEquals(Registration.lastname.getAttribute("value"), lastname);

		Registration.password.sendKeys(password);
		Assert.assertEquals(Registration.password.getAttribute("value"), password);

		String date[] = dob.split("/");
		select = new Select(Registration.days);
		select.selectByValue(date[0]);
		Assert.assertEquals(select.getFirstSelectedOption().getAttribute("value"), date[0]);

		select = new Select(Registration.months);
		select.selectByValue(date[1]);
		Assert.assertEquals(select.getFirstSelectedOption().getAttribute("value"), date[1]);

		select = new Select(Registration.years);
		select.selectByValue(date[2]);
		Assert.assertEquals(select.getFirstSelectedOption().getAttribute("value"), date[2]);

		Registration.company.sendKeys(company);
		Assert.assertEquals(Registration.company.getAttribute("value"), company);
		Registration.address1.sendKeys(address1);
		Assert.assertEquals(Registration.address1.getAttribute("value"), address1);
		Registration.address2.sendKeys(address2);
		Assert.assertEquals(Registration.address2.getAttribute("value"), address2);
		Registration.city.sendKeys(city);
		Assert.assertEquals(Registration.city.getAttribute("value"), city);

		select = new Select(Registration.state);
		select.selectByVisibleText(state);
		Assert.assertEquals(select.getFirstSelectedOption().getText(), state);

		Registration.postcode.sendKeys(pincode);
		Assert.assertEquals(Registration.postcode.getAttribute("value"), pincode);

		select = new Select(Registration.country);
		select.selectByVisibleText(country);
		Assert.assertEquals(select.getFirstSelectedOption().getText(), country);

		Registration.other.sendKeys(add_info);
		Assert.assertEquals(Registration.other.getAttribute("value"), add_info);

		Registration.phone.sendKeys(phone);
		Assert.assertEquals(Registration.phone.getAttribute("value"), phone);

		Registration.phone_mobile.sendKeys(mobile);
		Assert.assertEquals(Registration.phone_mobile.getAttribute("value"), mobile);

		Registration.alias.clear();
		Registration.alias.sendKeys(alias);
		Assert.assertEquals(Registration.alias.getAttribute("value"), alias);

		Registration.submit.click();

		if (element == null) {

			return false;
		} else {
			PropertyFileOperations.userSetFile(email, password);
			System.out.println("registration done");
			return true;
		}
	}

	public static boolean cart(String email, String password) {

		if (browser.equals("chrome")) {
			AcceptPage.acceptpage(driver, wait).click();
		}
		HomePage.Signin_Link(driver).click();

		// email=email+System.currentTimeMillis()+"@gmail.com";
		AddToCart.cartEmail(driver).sendKeys(email);

		AddToCart.cartpswd(driver).sendKeys(password);

		AddToCart.cartLogin(driver).click();

		AddToCart.selectItem(driver, wait).click();

		AddToCart.addCart(driver, wait).click();

		element = AddToCart.verify(driver, wait);
		if (element == null) {
			return false;
		} else {

			System.out.println("Successfully added to cart");
			return true;
		}

	}
}