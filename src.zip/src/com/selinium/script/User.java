package com.selinium.script;

import java.io.IOException;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selinium.base.Testbase;
import com.selinium.functions.Legacyfunctions;
import com.selinium.functions.PropertyFileOperations;
import com.selinium.functions.RetryAnalyser;
import com.selinium.functions.UserBrowser;
import com.selinium.util.TestUtil;

//@Listeners(com.selinium.listeners.Listener.class)
public class User extends Testbase {

	static boolean fail=false;
	static boolean skip=false;
	static boolean isTestPass=false;
	static int count=-1;
	
	String url;
	@Parameters({"browser","url"})
	@BeforeTest(alwaysRun=true)
	public void checkTestSkip(String browser,String url) {
		initialize();
		if (!TestUtil.isTestCaseRunnable(suiteAxls, this.getClass().getSimpleName())) {
			throw new SkipException("Skipping Test Case" + this.getClass().getSimpleName() + " as runmode set to NO");
		}
		Testbase.browser=browser;
		this.url=url;
	}
	
	@Test(/*groups={"Primary"},*/dataProvider="Registration"/*,retryAnalyzer = RetryAnalyser.class*/)
	public void userMethod(String email,String gender,String firstname,String lastname,String password,
			String dob,String company,String address1,String address2,
			String city,String state,String pincode,String country,
			String add_info,String phone,String mobile,String alias) throws IOException
	{
		UserBrowser.openbrowser(browser,url);
		Legacyfunctions.RegUser(email,gender,firstname,lastname,password,dob,company,address1,
				address2,city,state,pincode,country,add_info,phone,mobile,alias);
		UserBrowser.closeBrowser();
		isTestPass = true;
	}
	
	@DataProvider
	public Object[][] Registration() {
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName());

	}
	
	@Test(dependsOnMethods={"userMethod"},dataProvider="cart")
	public void cartMethod(String email,String password)
	{
		UserBrowser.openbrowser(browser,url);
		Legacyfunctions.cart(email, password);
		UserBrowser.closeBrowser();
		isTestPass = true;
	}
	
	@DataProvider
	public Object[][] cart() throws IOException{
		return PropertyFileOperations.userGetFile();
	}
	
	
	@AfterTest
	public void reportTestResult() {
		if (isTestPass)
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "FAIL");

	}

	@AfterMethod
	public void reportDataSetResult() {
		if (skip)
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					count + 2, "SKIP");
		else if (fail) {
			isTestPass = false;
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					count + 2, "FAIL");
		} else
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(),
					 count + 2, "PASS");

		skip = false;
		fail = false;
		driver.quit();

	}
}
