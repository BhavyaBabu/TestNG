package com.selinium.script;

import java.io.IOException;

import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selinium.base.Testbase;
import com.selinium.functions.Legacyfunctions;
import com.selinium.functions.UserBrowser;
import com.selinium.util.TestUtil;

public class SearchItems extends Testbase {

	static boolean fail = false;
	static boolean skip = false;
	static boolean isTestPass = false;
	static int count = -1;

	String url;

	//parameter specified in xml file can be passed directly to the functions using @Parameter annotation
	@Parameters({ "browser", "url" })
	@BeforeTest(alwaysRun = true)
	//checks whether the testcase is to be skipped or executed
	public void checkTestSkip(String browser, String url) {
		initialize();
		//checks whether the testcase is to be executed or not by checking the excel sheet value,if the value of
		   //testcase is 'Y' the testcase gets executed else not
		if (!TestUtil.isTestCaseRunnable(suiteAxls, this.getClass().getSimpleName())) {
			throw new SkipException("Skipping Test Case" + this.getClass().getSimpleName() + " as runmode set to NO");
		}
		Testbase.browser = browser;
		this.url = url;
	}

	@Test(priority=2,/*groups = {"Sanity"},*/dataProvider = "search"/*,expectedExceptions=ArithmeticException.class*/)
	public void searchMethod(String searchValue){
		UserBrowser.openbrowser(browser, url);
		//int a= 100/0;
		Legacyfunctions.Searchitem(searchValue);
		UserBrowser.closeBrowser();
		isTestPass = true;
	}

	@DataProvider
	public Object[][] search() {
		return TestUtil.getData(suiteAxls, this.getClass().getSimpleName());

	}
	
	@Test(priority=1,enabled=false)
	public void priorityMethod()
	{
		UserBrowser.openbrowser(browser, url);
		System.out.println("priority method gets executed first because it has the highest priority");
		UserBrowser.closeBrowser();
	}
	
	

	@AfterTest
	public void reportTestResult() {
		if (isTestPass)
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "PASS");
		else
			TestUtil.reportDataSetResult(suiteAxls, "Test Cases",
					TestUtil.getRowNum(suiteAxls, this.getClass().getSimpleName()), "FAIL");

	}

	@AfterMethod
	public void reportDataSetResult() {
		if (skip)
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "SKIP");
		else if (fail) {
			isTestPass = false;
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "FAIL");
		} else
			TestUtil.reportDataSetResult(suiteAxls, this.getClass().getSimpleName(), count + 2, "PASS");

		skip = false;
		fail = false;
		driver.quit();

	}

}
