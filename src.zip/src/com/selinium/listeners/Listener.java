package com.selinium.listeners;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;

public class Listener implements ITestListener,ISuiteListener,IInvokedMethodListener{

	//ITestListener method
	//executes before @Test
	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("The execution of the main test starts now");
		
	}

	//ITestListener method
	//executes when @Test is success
	@Override
	public void onTestSuccess(ITestResult result) {
		printTestResults(result);
		 
		
	}

	//ITestListener method
	//executes if the test fails
	@Override
	public void onTestFailure(ITestResult result) {
		printTestResults(result);
		
	}

	//ITestListener method
	//executes if the test skips
	@Override
	public void onTestSkipped(ITestResult result) {
		printTestResults(result);
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		
		
	}

	//ITestListener method
	//executes before the test start
	@Override
	public void onStart(ITestContext context) {
		Reporter.log("About to begin executing Test " + context.getName(), true);
		
	}

	//ITestListener method
	//executes after the test finishes
	@Override
	public void onFinish(ITestContext context) {
		Reporter.log("Completed executing test " + context.getName(), true);
		
	}
	
	//method to be called when test pass or skip or fail
	private void printTestResults(ITestResult result) {
		 
		Reporter.log("Test Method resides in " + result.getTestClass().getName(), true);
 
		if (result.getParameters().length != 0) {
 
			String params = " ";
 
			for (Object parameter : result.getParameters()) {
 
				params += parameter.toString() + ",";
 
			}
 
			Reporter.log("Test Method had the following parameters : " + params, true);
 
		}
 
		String status = null;
 
		switch (result.getStatus()) {
 
		case ITestResult.SUCCESS:
 
			status = "Pass";
 
			break;
 
		case ITestResult.FAILURE:
 
			status = "Failed";
 
			break;
 
		case ITestResult.SKIP:
 
			status = "Skipped";
 
		}
 
		Reporter.log("Test Status: " + status, true);
 
	}

	// ISuiteListener method 
	//executes before the Suite start
	@Override
	public void onStart(ISuite suite) {
		Reporter.log("About to begin executing Suite " + suite.getName(), true);
		 
		
	}

	
	// ISuiteListener method 
	//executes when the Suite finish
	@Override
	public void onFinish(ISuite suite) {
		Reporter.log("About to end executing Suite " + suite.getName(), true);
		
	}

	//IInvokedMethodListener method
	//executes before method
	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		String textMsg = "About to begin executing following method : " + returnMethodName(method.getTestMethod());
		 
		Reporter.log(textMsg, true);
		
	}

	//IInvokedMethodListener method
    //executes after method
	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		String textMsg = "Completed executing following method : " + returnMethodName(method.getTestMethod());
		 
		Reporter.log(textMsg, true);
 
		
	}
	
	//return the method name
	private String returnMethodName(ITestNGMethod method) {
		 
		return method.getRealClass().getSimpleName() + "." + method.getMethodName();
 
	}

}
